﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallControl : MonoBehaviour {

    //属性
    private float offset;
    //引用
    public GameObject player;

	// Use this for initialization
	void Start () {
        offset = gameObject.transform.position.x - player.transform.position.x;
	}
	
	// Update is called once per frame
	void Update () {
        //调用方法
        FollowPlayerMove();
    }

    //定义跟随玩家的方法
    public void FollowPlayerMove() {
        gameObject.transform.position = new Vector3(player.transform.position.x + offset, 0 , 0 );
    }
}
