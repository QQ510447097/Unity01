﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour {

    //属性
    public Rigidbody rd;
    public float speedAutoMove = 5;
    public float speedMoveUpAndDown = 20;

	// Use this for initialization
	void Start () {
        rd = gameObject.GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        PlayerAutoMove();
        PlayerMoveUpAndDown();
	}

    //小球自动运动
    private void PlayerAutoMove() {
        rd.AddForce(Vector3.right * speedMoveUpAndDown);
    }

    //小球控制进行上下运动
    private void PlayerMoveUpAndDown()
    {
        float v = Input.GetAxis("Vertical");
        rd.AddForce(v * speedMoveUpAndDown * Vector3.up);
    }
}
